import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DB {
  static Database? _db;
  static Future<Database> get database async {
    if (_db != null) return _db!;
    final p = join(await getDatabasesPath(), 'accounts_inventory_v3.db');
    _db = await openDatabase(p, version: 3, onCreate: (db,v) async {
      await _create(db);
    }, onUpgrade: (db,oldV,newV) async {
      if (oldV < 3) await _upgradeTo3(db);
    });
    return _db!;
  }

  static Future<void> _create(Database db) async {
    await db.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)');
    await db.execute('CREATE TABLE suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT)');
    await db.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,barcode TEXT,unit TEXT,buy REAL DEFAULT 0,sell REAL DEFAULT 0,qty REAL DEFAULT 0,min_qty REAL DEFAULT 0)');
    await db.execute('CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,party_id INTEGER,party_type TEXT,item_id INTEGER,qty REAL DEFAULT 0,price REAL DEFAULT 0,total REAL DEFAULT 0,paid REAL DEFAULT 0,date TEXT NOT NULL,note TEXT)');
    await db.execute('CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,party_id INTEGER NOT NULL,party_type TEXT NOT NULL,amount REAL NOT NULL,date TEXT NOT NULL,note TEXT)');
  }
  static Future<void> _upgradeTo3(Database db) async {
    await db.execute('CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,party_id INTEGER NOT NULL,party_type TEXT NOT NULL,amount REAL NOT NULL,date TEXT NOT NULL,note TEXT)');
  }

  static Future<List<Map<String,dynamic>>> all(String t,{String? where,List<Object?>? args}) async =>
      (await database).query(t,where:where,whereArgs:args,orderBy:'id DESC');
  static Future<int> insert(String t,Map<String,dynamic> d)=>database.then((x)=>x.insert(t,d));
  static Future<int> update(String t,int id,Map<String,dynamic> d)=>database.then((x)=>x.update(t,d,where:'id=?',whereArgs:[id]));
  static Future<int> delete(String t,int id)=>database.then((x)=>x.delete(t,where:'id=?',whereArgs:[id]));

  static Future<void> operation({required String kind,required int partyId,required String partyType,required int itemId,required double qty,required double price,required double paid,required String note}) async {
    final db=await database; final total=qty*price;
    await db.transaction((tx) async {
      await tx.insert('transactions',{'kind':kind,'party_id':partyId,'party_type':partyType,'item_id':itemId,'qty':qty,'price':price,'total':total,'paid':paid,'date':DateTime.now().toIso8601String(),'note':note});
      if(paid > 0) await tx.insert('payments',{'party_id':partyId,'party_type':partyType,'amount':paid,'date':DateTime.now().toIso8601String(),'note':'دفعة مرتبطة بفاتورة $kind'});
      await tx.rawUpdate('UPDATE products SET qty=qty+? WHERE id=?',[kind=='sale'?-qty:qty,itemId]);
    });
  }

  static Future<void> addPayment({required int partyId,required String partyType,required double amount,required String note}) async {
    await (await database).insert('payments',{'party_id':partyId,'party_type':partyType,'amount':amount,'date':DateTime.now().toIso8601String(),'note':note});
  }

  static Future<List<Map<String,dynamic>>> statement(String type,int id) async {
    final db=await database;
    final tx=await db.query('transactions',where:'party_type=? AND party_id=?',whereArgs:[type,id],orderBy:'date DESC');
    final pay=await db.query('payments',where:'party_type=? AND party_id=?',whereArgs:[type,id],orderBy:'date DESC');
    return [...tx.map((e)=>{...e,'entry_type':'invoice'}),...pay.map((e)=>{...e,'entry_type':'payment','total':0,'paid':e['amount'],'kind':'payment'})]
      ..sort((a,b)=>b['date'].toString().compareTo(a['date'].toString()));
  }

  static Future<String> exportBackup() async {
    final db=await database;
    final tables=['customers','suppliers','products','transactions','payments'];
    final data=<String,dynamic>{'format':'accounts_inventory_backup','version':3,'created_at':DateTime.now().toIso8601String()};
    for(final t in tables) data[t]=await db.query(t);
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  static Future<void> importBackup(String json) async {
    final decoded=jsonDecode(json);
    if(decoded is! Map || decoded['format']!='accounts_inventory_backup') {
      throw Exception('ملف النسخة الاحتياطية غير صالح');
    }
    final db=await database;
    final tables=['customers','suppliers','products','transactions','payments'];
    await db.transaction((tx) async {
      for(final t in tables) {
        await tx.delete(t);
        final rows=decoded[t];
        if(rows is List) {
          for(final row in rows) {
            final map=Map<String,dynamic>.from(row as Map);
            await tx.insert(t,map);
          }
        }
      }
    });
  }
}
