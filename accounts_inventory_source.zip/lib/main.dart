import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'db.dart';

void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const App());}

class App extends StatelessWidget{
 const App({super.key});
 @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'إدارة الحسابات',theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.indigo),home:const Directionality(textDirection:TextDirection.rtl,child:Home()));
}

class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home>{
 int tab=0;
 @override Widget build(BuildContext c){
  final pages=[const Dashboard(),const PartyPage(type:'customer'),const PartyPage(type:'supplier'),const ProductPage(),const InvoicePage()];
  return Scaffold(appBar:AppBar(title:const Text('إدارة الحسابات والمخزون'),centerTitle:true),body:pages[tab],
   bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[
    NavigationDestination(icon:Icon(Icons.home),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.people),label:'العملاء'),NavigationDestination(icon:Icon(Icons.factory),label:'الموردون'),NavigationDestination(icon:Icon(Icons.inventory_2),label:'الأصناف'),NavigationDestination(icon:Icon(Icons.receipt_long),label:'فاتورة')
   ]));
 }
}

class Dashboard extends StatelessWidget{const Dashboard({super.key});
 @override Widget build(BuildContext c)=>FutureBuilder(future:Future.wait([DB.all('customers'),DB.all('suppliers'),DB.all('products'),DB.all('transactions')]),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  final x=s.data!; double sales=0,purchases=0; for(final r in x[3]){if(r['kind']=='sale')sales+=(r['total'] as num).toDouble();else purchases+=(r['total'] as num).toDouble();}
  return ListView(padding:const EdgeInsets.all(16),children:[
   const Text('لوحة التحكم',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:14),
   Wrap(spacing:10,runSpacing:10,children:[Stat('العملاء',x[0].length,Icons.people),Stat('الموردون',x[1].length,Icons.factory),Stat('الأصناف',x[2].length,Icons.inventory_2),Stat('الوحدات',x[2].fold<double>(0,(a,e)=>a+(e['qty'] as num).toDouble()),Icons.warehouse)]),
   const SizedBox(height:12),Card(child:ListTile(title:const Text('إجمالي المبيعات'),trailing:Text('${sales.toStringAsFixed(2)} ج.م'))),
   Card(child:ListTile(title:const Text('إجمالي المشتريات'),trailing:Text('${purchases.toStringAsFixed(2)} ج.م'))),
   const SizedBox(height:8),
   FilledButton.icon(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const BackupPage())),icon:const Icon(Icons.backup),label:const Text('النسخ الاحتياطي والاستعادة')),
  ]);
 });}
class Stat extends StatelessWidget{final String t;final Object v;final IconData i;const Stat(this.t,this.v,this.i,{super.key});@override Widget build(BuildContext c)=>SizedBox(width:155,child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Icon(i,size:30),Text(t),Text('$v',style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold))]))));}

class PartyPage extends StatefulWidget{final String type;const PartyPage({super.key,required this.type});@override State<PartyPage> createState()=>_PartyState();}
class _PartyState extends State<PartyPage>{
 String search='';
 Future<void> edit([Map<String,dynamic>? old])async{
  final n=TextEditingController(text:old?['name']??''),p=TextEditingController(text:old?['phone']??''),a=TextEditingController(text:old?['address']??''),no=TextEditingController(text:old?['notes']??'');
  final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(old==null?(widget.type=='customer'?'إضافة عميل':'إضافة مورد'):'تعديل'),content:SingleChildScrollView(child:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'الاسم')),TextField(controller:p,decoration:const InputDecoration(labelText:'الهاتف')),TextField(controller:a,decoration:const InputDecoration(labelText:'العنوان')),TextField(controller:no,decoration:const InputDecoration(labelText:'ملاحظات'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('حفظ'))])); 
  if(ok==true&&n.text.trim().isNotEmpty){final d={'name':n.text,'phone':p.text,'address':a.text,'notes':no.text};old==null?await DB.insert(widget.type=='customer'?'customers':'suppliers',d):await DB.update(widget.type=='customer'?'customers':'suppliers',old['id'],d);setState((){});}
 }
 @override Widget build(BuildContext c)=>FutureBuilder(future:DB.all(widget.type=='customer'?'customers':'suppliers'),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());final rows=s.data!.where((r)=>r['name'].toString().contains(search)||r['phone'].toString().contains(search)).toList();
  return Column(children:[Padding(padding:const EdgeInsets.all(10),child:TextField(onChanged:(v)=>setState(()=>search=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'بحث بالاسم أو الهاتف',border:OutlineInputBorder()))),
   Expanded(child:ListView.builder(itemCount:rows.length,itemBuilder:(_,i){final r=rows[i];return Card(child:ListTile(title:Text(r['name']),subtitle:Text(r['phone']??''),leading:CircleAvatar(child:Text('${i+1}')),trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='edit')await edit(r);if(v=='delete'){await DB.delete(widget.type=='customer'?'customers':'suppliers',r['id']);setState((){});}},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('تعديل')),PopupMenuItem(value:'delete',child:Text('حذف'))]),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Statement(id:r['id'],name:r['name'],type:widget.type))));})),
  ]); 
 });
}

class ProductPage extends StatefulWidget{const ProductPage({super.key});@override State<ProductPage> createState()=>_ProductState();}
class _ProductState extends State<ProductPage>{
 String search='';
 Future<void> edit([Map<String,dynamic>? old])async{
  final n=TextEditingController(text:old?['name']??''),b=TextEditingController(text:old?['barcode']??''),u=TextEditingController(text:old?['unit']??'قطعة'),buy=TextEditingController(text:'${old?['buy']??0}'),sell=TextEditingController(text:'${old?['sell']??0}'),q=TextEditingController(text:'${old?['qty']??0}'),m=TextEditingController(text:'${old?['min_qty']??0}');
  final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(old==null?'إضافة صنف':'تعديل صنف'),content:SingleChildScrollView(child:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'اسم الصنف')),TextField(controller:b,decoration:const InputDecoration(labelText:'الباركود')),TextField(controller:u,decoration:const InputDecoration(labelText:'الوحدة')),TextField(controller:buy,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'سعر الشراء')),TextField(controller:sell,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'سعر البيع')),TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الكمية الحالية')),TextField(controller:m,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الحد الأدنى للمخزون'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('حفظ'))])); 
  if(ok==true&&n.text.trim().isNotEmpty){final d={'name':n.text,'barcode':b.text,'unit':u.text,'buy':double.tryParse(buy.text)??0,'sell':double.tryParse(sell.text)??0,'qty':double.tryParse(q.text)??0,'min_qty':double.tryParse(m.text)??0};old==null?await DB.insert('products',d):await DB.update('products',old['id'],d);setState((){});}
 }
 @override Widget build(BuildContext c)=>FutureBuilder(future:DB.all('products'),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final rows=s.data!.where((r)=>r['name'].toString().contains(search)||r['barcode'].toString().contains(search)).toList();return Column(children:[Padding(padding:const EdgeInsets.all(10),child:TextField(onChanged:(v)=>setState(()=>search=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'بحث باسم الصنف أو الباركود',border:OutlineInputBorder()))),Expanded(child:ListView.builder(itemCount:rows.length,itemBuilder:(_,i){final r=rows[i];final low=(r['qty'] as num)<= (r['min_qty'] as num);return Card(child:ListTile(title:Text(r['name']),subtitle:Text('الكمية: ${r['qty']} ${r['unit']} | بيع: ${r['sell']} ج.م'+(low?' | ⚠️ مخزون منخفض':'')),trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='edit')await edit(r);if(v=='delete'){await DB.delete('products',r['id']);setState((){});}},itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('تعديل')),PopupMenuItem(value:'delete',child:Text('حذف'))]));})),]);});
}

class InvoicePage extends StatefulWidget{const InvoicePage({super.key});@override State<InvoicePage> createState()=>_InvoiceState();}
class _InvoiceState extends State<InvoicePage>{
 String kind='sale';Map<String,dynamic>? party,item;double qty=1,price=0,paid=0;final note=TextEditingController();
 @override Widget build(BuildContext c)=>FutureBuilder(future:Future.wait([DB.all(kind=='sale'?'customers':'suppliers'),DB.all('products')]),builder:(c,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());final parties=s.data![0],products=s.data![1];price=item?['sell']??0;
  return ListView(padding:const EdgeInsets.all(16),children:[
   SegmentedButton<String>(segments:const[ButtonSegment(value:'sale',label:Text('بيع'),icon:Icon(Icons.point_of_sale)),ButtonSegment(value:'purchase',label:Text('شراء'),icon:Icon(Icons.shopping_cart))],selected:{kind},onSelectionChanged:(v)=>setState(()=>{kind=v.first;party=null;item=null;})),
   const SizedBox(height:18),
   DropdownButtonFormField<Map<String,dynamic>>(value:party,decoration:InputDecoration(labelText:kind=='sale'?'العميل':'المورد'),items:parties.map((x)=>DropdownMenuItem(value:x,child:Text(x['name']))).toList(),onChanged:(v)=>setState(()=>party=v)),
   const SizedBox(height:10),
   DropdownButtonFormField<Map<String,dynamic>>(value:item,decoration:const InputDecoration(labelText:'الصنف'),items:products.map((x)=>DropdownMenuItem(value:x,child:Text('${x['name']} — ${x['qty']} متاح'))).toList(),onChanged:(v)=>setState(()=>item=v)),
   TextFormField(initialValue:'1',keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الكمية'),onChanged:(v)=>qty=double.tryParse(v)??1),
   TextFormField(key:ValueKey(item?['id']),initialValue:'${item==null?0:(kind=='sale'?item!['sell']:item!['buy'])}',keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'السعر'),onChanged:(v)=>price=double.tryParse(v)??0),
   TextFormField(key:const ValueKey('paid'),initialValue:'0',keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'المدفوع'),onChanged:(v)=>paid=double.tryParse(v)??0),
   TextField(controller:note,decoration:const InputDecoration(labelText:'البيان')),
   const SizedBox(height:18),
   Card(child:ListTile(title:const Text('الإجمالي'),trailing:Text('${(qty*price).toStringAsFixed(2)} ج.م',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)))),
   FilledButton.icon(onPressed:party==null||item==null?null:()async{if(kind=='sale'&&(item!['qty'] as num)<qty){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('الكمية غير متوفرة في المخزون')));return;}await DB.operation(kind:kind,partyId:party!['id'],partyType:kind=='sale'?'customer':'supplier',itemId:item!['id'],qty:qty,price:price,paid:paid,note:note.text);if(c.mounted)ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('تم حفظ الفاتورة وتحديث المخزون والحساب')));setState((){party=null;item=null;qty=1;price=0;paid=0;note.clear();});},icon:const Icon(Icons.save),label:const Text('حفظ الفاتورة')),
  ]);
 });
}

class Statement extends StatelessWidget{final int id;final String name,type;const Statement({super.key,required this.id,required this.name,required this.type});
 Future<void> _payment(BuildContext c) async {
   final amount=TextEditingController(), note=TextEditingController();
   final ok=await showDialog<bool>(context:c,builder:(_)=>AlertDialog(title:Text(type=='customer'?'دفعة من العميل':'دفعة للمورد'),content:Column(mainAxisSize:MainAxisSize.min,children:[
     TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'المبلغ')),
     TextField(controller:note,decoration:const InputDecoration(labelText:'البيان')),
   ]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حفظ'))]));
   if(ok==true){
     final v=double.tryParse(amount.text)??0;
     if(v>0){await DB.addPayment(partyId:id,partyType:type,amount:v,note:note.text);if(c.mounted) Navigator.pop(c); }
   }
 }

 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text('كشف حساب $name')),body:FutureBuilder(future:DB.statement(type,id),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final rows=s.data!;double balance=0;for(final r in rows){if(r['entry_type']=='invoice') balance+=(r['total'] as num).toDouble(); else balance-=(r['amount'] as num).toDouble();}return Column(children:[Card(margin:const EdgeInsets.all(12),child:Column(children:[ListTile(title:const Text('الرصيد المستحق'),trailing:Text('${balance.toStringAsFixed(2)} ج.م',style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold))),FilledButton.icon(onPressed:()=>_payment(c),icon:const Icon(Icons.payments),label:Text(type=='customer'?'تسجيل دفعة من العميل':'تسجيل دفعة للمورد'))])),Expanded(child:ListView.builder(itemCount:rows.length,itemBuilder:(_,i){final r=rows[i];return Card(child:ListTile(title:Text(r['kind']=='sale'?'فاتورة بيع':'فاتورة شراء'),subtitle:Text('${DateFormat('yyyy/MM/dd HH:mm').format(DateTime.parse(r['date']))}\\n${r['note']??''}'),trailing:Text('الإجمالي ${r['total']}\\nالمدفوع ${r['paid']}'));})),]);}));
}


class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override State<BackupPage> createState()=>_BackupPageState();
}
class _BackupPageState extends State<BackupPage>{
  bool busy=false;
  Future<void> backup() async {
    setState(()=>busy=true);
    try {
      final json=await DB.exportBackup();
      final path=await FilePicker.platform.saveFile(
        dialogTitle:'حفظ النسخة الاحتياطية',
        fileName:'accounts_backup_${DateFormat('yyyyMMdd_HHmm').format(DateTime.now())}.json',
        type:FileType.custom,allowedExtensions:['json']);
      if(path!=null){
        final bytes=utf8.encode(json);
        // saveFile returns a writable path on Android/Desktop configurations.
        // If a provider doesn't return a direct path, users can use the system picker.
        final f=FilePicker.platform;
        await _writePicked(path,bytes);
        if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم إنشاء النسخة الاحتياطية بنجاح')));
      }
    }catch(e){if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء النسخة: $e')));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> _writePicked(String path,List<int> bytes) async {
    // file_picker does not expose a universal write API. Use dart:io on platforms with a filesystem path.
    final file=File(path); await file.writeAsBytes(bytes,flush:true);
  }
  Future<void> restore() async {
    setState(()=>busy=true);
    try{
      final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);
      if(result==null){setState(()=>busy=false);return;}
      final data=result.files.single.bytes;
      String json;
      if(data!=null) json=utf8.decode(data);
      else if(result.files.single.path!=null) json=await File(result.files.single.path!).readAsString();
      else throw Exception('تعذر قراءة الملف');
      await DB.importBackup(json);
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تمت استعادة البيانات بنجاح')));
    }catch(e){if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر الاستعادة: $e')));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('النسخ الاحتياطي والاستعادة')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
    const Icon(Icons.cloud_sync,size:70),const SizedBox(height:16),
    const Text('النسخة الاحتياطية تحفظ العملاء والموردين والأصناف والفواتير والدفعات في ملف JSON.',textAlign:TextAlign.center,style:TextStyle(fontSize:17)),
    const SizedBox(height:25),
    FilledButton.icon(onPressed:busy?null:backup,icon:const Icon(Icons.download),label:const Text('إنشاء نسخة احتياطية')),
    const SizedBox(height:12),
    OutlinedButton.icon(onPressed:busy?null:restore,icon:const Icon(Icons.upload_file),label:const Text('استعادة نسخة احتياطية')),
    if(busy) const Padding(padding:EdgeInsets.all(20),child:CircularProgressIndicator()),
  ]));
}
